var picCountA=0;
var picCountP=0;
var picCountT=0;
