$.get("subgallery/activity.html",function(data){
	$(".activitygallerycontent").load("subgallery/activity.html img");
});
$.get("subgallery/past.html",function(data){
	$(".pastgallerycontent").load("subgallery/past.html img");
});
$.get("subgallery/activity.html",function(data){
	$(".togethergallerycontent").load("subgallery/together.html img");
});