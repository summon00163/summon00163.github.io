// JavaScript Document
document.writeln("<footer>");
document.writeln("	<span>联系我们：</span><br/>");
document.writeln("	<span><a href=\'tel:\'>0769-**** ****</a></span><br/>");
document.writeln("	<span><a href=\'mailto:\'>******@***.com</a></span><br/>");
document.writeln("	<span><a href=\'https://beian.miit.gov.cn/#/Integrated/index\'>粤ICP备********号-*</a></span><br/>");
document.writeln("	<span><a href=\'source-code.zip\'>源码下载</a></span><br/>");
document.writeln("	<span><a href=\'https://github.com/summon00163/summon00163.github.io\'>源码查看</a></span><br/>");
document.writeln("</footer>");